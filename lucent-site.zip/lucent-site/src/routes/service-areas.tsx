import { createFileRoute, Link } from "@tanstack/react-router";
import ext from "@/assets/exterior-home.jpg";
import { PageHero } from "@/components/site/Layout";
import { AREAS } from "@/lib/site";

export const Route = createFileRoute("/service-areas")({
  head: () => ({
    meta: [
      { title: "Service Areas: Grand Rapids, Lansing & Traverse City Painters | Lucent" },
      { name: "description", content: "Painting contractor serving Grand Rapids MI, Lansing MI, Traverse City MI and the communities around them. Commercial and residential painters." },
      { property: "og:title", content: "Service Areas | Lucent General Contractors" },
      { property: "og:description", content: "Painting & construction across Grand Rapids, Lansing and Traverse City." },
    ],
  }),
  component: Areas,
});

const EXTRA = [
  { h: "Commercial Painter Michigan", body: "Offices, retail, restaurants and multi-family properties trust Lucent for commercial painting with after-hours scheduling and minimal disruption." },
  { h: "Residential Painter Michigan", body: "Homeowners in Grand Rapids, Lansing and Traverse City choose Lucent for clean job sites, honest communication and finishes that last." },
  { h: "General Contractor Michigan", body: "Beyond painting, we handle drywall, remodeling, light construction, rental turnovers and property maintenance in Grand Rapids, Lansing, Traverse City and the communities around them." },
];

function Areas() {
  return (
    <>
      <PageHero eyebrow="Service Areas" title="Serving Grand Rapids, Lansing & Traverse City" image={ext} />
      <section className="mx-auto max-w-7xl px-5 py-24 lg:px-8">
        <div className="grid gap-12 lg:grid-cols-3">
          {AREAS.map((a) => (
            <article key={a.slug} id={a.slug} className="scroll-mt-28 border-t-2 border-gold pt-8">
              <h2 className="text-3xl">{a.h}</h2>
              <p className="mt-4 text-muted-foreground leading-relaxed">{a.body}</p>
              <Link to="/contact" className="mt-6 inline-block text-xs uppercase tracking-[0.2em] text-gold">Request an estimate in {a.city} →</Link>
            </article>
          ))}
        </div>
        <div className="mt-20 grid gap-12 lg:grid-cols-3">
          {EXTRA.map((e) => (
            <article key={e.h} className="border-t border-border pt-8">
              <h2 className="text-2xl">{e.h}</h2>
              <p className="mt-4 text-muted-foreground leading-relaxed">{e.body}</p>
            </article>
          ))}
        </div>
      </section>
      <section className="h-[28rem] w-full">
        <iframe title="Michigan service area map" className="h-full w-full grayscale" loading="lazy" src="https://www.google.com/maps?q=Michigan&z=6&output=embed" />
      </section>
    </>
  );
}
