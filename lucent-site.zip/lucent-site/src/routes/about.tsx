import { createFileRoute, Link } from "@tanstack/react-router";
import craft from "@/assets/craft-detail.jpg";
import logo from "@/assets/business_logo.png";
import { PageHero } from "@/components/site/Layout";
import { SITE } from "@/lib/site";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About James Felton | Lucent General Contractors" },
      { name: "description", content: "Meet James Felton, founder of Lucent General Contractors — a locally owned Michigan painting and construction company serving Grand Rapids, Lansing & Traverse City." },
      { property: "og:title", content: "About Lucent General Contractors" },
      { property: "og:description", content: "Locally owned, built on years of professional painting experience." },
    ],
  }),
  component: About,
});

const VALUES = ["Integrity", "Reliability", "Professionalism", "Quality Craftsmanship", "Customer Satisfaction", "Community Commitment"];

function About() {
  return (
    <>
      <PageHero eyebrow="About Lucent" title={SITE.tagline} image={craft} />
      <section className="mx-auto grid max-w-7xl items-center gap-16 px-5 py-28 lg:grid-cols-2 lg:px-8">
        <div className="relative">
          <div className="aspect-square bg-ink flex items-center justify-center">
            <img src={logo.url} alt="Lucent General Contractors" className="w-2/3" />
          </div>
          <div className="absolute -bottom-6 -right-6 hidden h-40 w-40 border border-gold md:block" />
        </div>
        <div>
          <p className="eyebrow">Meet the Owner</p>
          <h2 className="mt-4 text-5xl">James Felton</h2>
          <span className="gold-rule mt-6" />
          <p className="mt-8 text-lg leading-relaxed text-muted-foreground">
            James Felton founded Lucent General Contractors after years of professional painting experience. His goal is to provide homeowners, businesses, property managers, builders, and real estate investors with dependable service, exceptional craftsmanship, and honest communication.
          </p>
          <p className="mt-5 leading-relaxed text-muted-foreground">
            Lucent General Contractors is a locally owned company committed to delivering quality work and treating every project with professionalism and care. From a single accent wall to a full commercial build-out, James personally stands behind every job.
          </p>
          <Link to="/contact" className="btn-gold mt-10">Work With James</Link>
        </div>
      </section>
      <section className="bg-card py-24">
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <p className="eyebrow">Our Values</p>
          <div className="mt-10 grid gap-px bg-border sm:grid-cols-2 lg:grid-cols-3">
            {VALUES.map((v, i) => (
              <div key={v} className="bg-card p-10">
                <span className="font-display text-gold">{String(i + 1).padStart(2, "0")}</span>
                <p className="mt-4 font-display text-3xl">{v}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
