import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Phone, ClipboardCheck, Zap, Home, Building2, Hammer, CalendarDays, ShieldCheck, MessageSquare, Gem, CalendarClock } from "lucide-react";
import hero from "@/assets/hero-painting.jpg";
import craft from "@/assets/craft-detail.jpg";
import { SERVICES, SITE, FAQS, AREAS } from "@/lib/site";
import { Gallery } from "@/components/site/Gallery";
import { TrustBadges } from "@/components/site/Layout";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Painter Grand Rapids MI | Lucent General Contractors" },
      { name: "description", content: "Professional interior, exterior & commercial painting and construction in Grand Rapids, Lansing & Traverse City, Michigan. Free estimates." },
      { property: "og:title", content: "Lucent General Contractors — Painting & Construction in Grand Rapids, Lansing & Traverse City" },
      { property: "og:description", content: "Trusted painting & construction professionals in Grand Rapids, Lansing & Traverse City. Free estimates." },
    ],
  }),
  component: Index,
});

const WHY = [
  { i: ClipboardCheck, t: "Free Estimates" },
  { i: Zap, t: "Fast Response Times" },
  { i: Home, t: "Locally Owned" },
  { i: Building2, t: "Residential & Commercial" },
  { i: Hammer, t: "Experienced Craftsmanship" },
  { i: CalendarDays, t: "Weekend Availability" },
  { i: ShieldCheck, t: "Quality Guaranteed" },
  { i: MessageSquare, t: "Professional Communication" },
  { i: Gem, t: "Detail-Oriented Workmanship" },
  { i: CalendarClock, t: "Reliable Scheduling" },
];
const INDUSTRIES = ["Homeowners", "Property Managers", "Real Estate Investors", "House Flippers", "Builders", "Commercial Property Owners", "Restaurants", "Retail Spaces", "Office Buildings", "Multi-Family Housing"];
const STEPS = ["Request Free Estimate", "Free Consultation", "Detailed Proposal", "Project Scheduling", "Professional Completion", "Final Walkthrough"];

function Index() {
  return (
    <>
      <section className="relative flex min-h-screen items-center overflow-hidden bg-ink">
        <img src={hero} alt="Freshly painted luxury living room in a Grand Rapids home" width={1920} height={1088} className="absolute inset-0 h-full w-full object-cover" />
        <div className="absolute inset-0 bg-hero-overlay" />
        <div className="relative mx-auto w-full max-w-7xl px-5 pt-32 pb-20 lg:px-8">
          <div className="max-w-3xl animate-rise">
            <p className="eyebrow">Serving Grand Rapids · Lansing · Traverse City</p>
            <h1 className="mt-6 text-5xl leading-[1.02] text-ivory md:text-7xl">
              Professional Painting & Construction Services in <em className="text-gold">Grand Rapids, Lansing & Traverse City</em>
            </h1>
            <p className="mt-7 max-w-2xl text-lg font-light text-ivory/80">
              Serving homeowners, businesses, property managers, builders, and real estate investors with dependable service, quality craftsmanship, and professional results.
            </p>
            <div className="mt-10 flex flex-wrap gap-4">
              <Link to="/contact" className="btn-gold">Get Free Estimate <ArrowRight className="h-4 w-4" /></Link>
              <a href={SITE.phoneHref} className="btn-outline-light"><Phone className="h-4 w-4" /> Call Now</a>
            </div>
            <TrustBadges dark />
          </div>
        </div>
      </section>

      {/* Why */}
      <section className="mx-auto max-w-7xl px-5 py-28 lg:px-8">
        <div className="grid gap-16 lg:grid-cols-[1fr_2fr]">
          <div>
            <p className="eyebrow">Why Choose Lucent</p>
            <h2 className="mt-4 text-4xl md:text-5xl leading-tight">Craftsmanship you can trust, communication you can count on.</h2>
            <span className="gold-rule mt-8" />
          </div>
          <div className="grid grid-cols-2 gap-px bg-border sm:grid-cols-3 lg:grid-cols-5">
            {WHY.map(({ i: I, t }) => (
              <div key={t} className="group bg-background p-6 transition-colors hover:bg-ink">
                <I className="h-7 w-7 text-gold" strokeWidth={1.25} />
                <p className="mt-5 text-sm leading-snug group-hover:text-ivory">{t}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Services */}
      <section className="bg-card py-28">
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <div className="flex flex-wrap items-end justify-between gap-6">
            <div>
              <p className="eyebrow">Our Services</p>
              <h2 className="mt-4 text-4xl md:text-5xl">Painting first. Construction done right.</h2>
            </div>
            <Link to="/services" className="btn-outline-dark">All Services</Link>
          </div>
          <div className="mt-14 grid gap-px bg-border sm:grid-cols-2 lg:grid-cols-5">
            {SERVICES.map((s, idx) => (
              <Link key={s.slug} to="/services/$slug" params={{ slug: s.slug }} className="group relative bg-card p-8 transition-all hover:bg-ink">
                <span className="font-display text-sm text-gold">{String(idx + 1).padStart(2, "0")}</span>
                <h3 className="mt-6 text-2xl group-hover:text-ivory">{s.title}</h3>
                <p className="mt-3 text-sm text-muted-foreground group-hover:text-ivory/60">{s.short}</p>
                <ArrowRight className="mt-6 h-4 w-4 text-gold transition-transform group-hover:translate-x-1" />
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Portfolio */}
      <section className="mx-auto max-w-7xl px-5 py-28 lg:px-8">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div>
            <p className="eyebrow">Recent Work</p>
            <h2 className="mt-4 text-4xl md:text-5xl">Our Portfolio</h2>
          </div>
          <Link to="/portfolio" className="btn-outline-dark">View Portfolio</Link>
        </div>
        <div className="mt-12"><Gallery /></div>
      </section>

      {/* Industries */}
      <section className="relative overflow-hidden bg-ink py-28 text-ivory">
        <img src={craft} alt="" loading="lazy" className="absolute inset-0 h-full w-full object-cover opacity-25" />
        <div className="relative mx-auto max-w-7xl px-5 lg:px-8">
          <p className="eyebrow">Industries Served</p>
          <h2 className="mt-4 max-w-2xl text-4xl md:text-5xl">Trusted by owners, managers and builders in Grand Rapids, Lansing & Traverse City.</h2>
          <div className="mt-12 flex flex-wrap gap-3">
            {INDUSTRIES.map((i) => (
              <span key={i} className="border border-ivory/20 px-5 py-3 text-xs uppercase tracking-[0.2em] text-ivory/85 hover:border-gold hover:text-gold transition-colors">{i}</span>
            ))}
          </div>
        </div>
      </section>

      {/* Process */}
      <section className="mx-auto max-w-7xl px-5 py-28 lg:px-8">
        <p className="eyebrow">Our Process</p>
        <h2 className="mt-4 text-4xl md:text-5xl">Six steps to a flawless finish.</h2>
        <ol className="mt-14 grid gap-10 sm:grid-cols-2 lg:grid-cols-3">
          {STEPS.map((s, i) => (
            <li key={s} className="border-t border-foreground/15 pt-6">
              <span className="font-display text-5xl text-gold">{i + 1}</span>
              <p className="mt-3 text-lg">{s}</p>
            </li>
          ))}
        </ol>
        <Link to="/contact" className="btn-gold mt-14">Start With Step One</Link>
      </section>

      {/* Areas */}
      <section className="bg-card py-24">
        <div className="mx-auto grid max-w-7xl gap-10 px-5 md:grid-cols-3 lg:px-8">
          {AREAS.map((a) => (
            <Link key={a.slug} to="/service-areas" hash={a.slug} className="group border border-border p-8 hover:border-gold transition-colors">
              <p className="eyebrow">Serving</p>
              <h3 className="mt-3 text-3xl">{a.city}, MI</h3>
              <p className="mt-3 text-sm text-muted-foreground">{a.body.slice(0, 120)}…</p>
            </Link>
          ))}
        </div>
      </section>

      {/* FAQ */}
      <section className="mx-auto max-w-4xl px-5 py-28 lg:px-8">
        <p className="eyebrow text-center">FAQ</p>
        <h2 className="mt-4 text-center text-4xl md:text-5xl">Frequently Asked Questions</h2>
        <div className="mt-12 divide-y divide-border border-y border-border">
          {FAQS.map((f) => (
            <details key={f.q} className="group py-6">
              <summary className="flex cursor-pointer list-none items-center justify-between font-display text-xl">
                {f.q}<span className="text-gold transition-transform group-open:rotate-45 text-2xl">+</span>
              </summary>
              <p className="mt-3 text-muted-foreground">{f.a}</p>
            </details>
          ))}
        </div>
      </section>
    </>
  );
}
