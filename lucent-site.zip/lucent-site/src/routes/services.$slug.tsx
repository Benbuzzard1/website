import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { Check, Phone } from "lucide-react";
import hero from "@/assets/hero-painting.jpg";
import ext from "@/assets/exterior-home.jpg";
import craft from "@/assets/craft-detail.jpg";
import { PageHero } from "@/components/site/Layout";
import { SERVICES, SITE, AREAS } from "@/lib/site";

export const Route = createFileRoute("/services/$slug")({
  loader: ({ params }) => {
    const service = SERVICES.find((s) => s.slug === params.slug);
    if (!service) throw notFound();
    return { service };
  },
  head: ({ loaderData }) => {
    const s = loaderData?.service;
    if (!s) return { meta: [{ title: "Service not found | Lucent" }, { name: "robots", content: "noindex" }] };
    const title = `${s.title} in Grand Rapids, Lansing & Traverse City | Lucent General Contractors`;
    return {
      meta: [
        { title },
        { name: "description", content: `${s.short} Serving Grand Rapids, Lansing & Traverse City. Free estimates.` },
        { property: "og:title", content: title },
        { property: "og:description", content: s.short },
      ],
    };
  },
  component: ServicePage,
  notFoundComponent: () => (
    <div className="py-48 text-center"><h1 className="text-4xl">Service not found</h1><Link to="/services" className="btn-gold mt-8">All Services</Link></div>
  ),
});

function ServicePage() {
  const { service: s } = Route.useLoaderData();
  const img = s.slug.includes("exterior") ? ext : s.primary ? hero : craft;
  const others = SERVICES.filter((x) => x.slug !== s.slug).slice(0, 4);
  return (
    <>
      <PageHero eyebrow={s.keyword} title={s.title} sub={s.short} image={img} />
      <section className="mx-auto grid max-w-7xl gap-16 px-5 py-24 lg:grid-cols-[2fr_1fr] lg:px-8">
        <div>
          <h2 className="text-4xl">{s.title} by Lucent General Contractors</h2>
          <span className="gold-rule mt-6" />
          <p className="mt-8 text-lg leading-relaxed text-muted-foreground">{s.intro}</p>
          <p className="mt-6 leading-relaxed text-muted-foreground">
            Founded by {SITE.owner}, Lucent is a locally owned company serving {AREAS.map((a) => a.city).join(", ")} and the communities around them. Every {s.title.toLowerCase()} project includes a free written estimate, reliable scheduling and a final walkthrough to make sure you're completely satisfied.
          </p>
          <h3 className="mt-12 text-2xl">What's included</h3>
          <ul className="mt-6 grid gap-4 sm:grid-cols-2">
            {s.points.map((p) => (
              <li key={p} className="flex items-start gap-3"><Check className="mt-0.5 h-5 w-5 text-gold" />{p}</li>
            ))}
          </ul>
        </div>
        <aside className="h-fit bg-ink p-10 text-ivory lg:sticky lg:top-28">
          <p className="eyebrow">Free Estimate</p>
          <p className="mt-3 font-display text-3xl">Start your {s.title.toLowerCase()} project.</p>
          <Link to="/contact" className="btn-gold mt-8 w-full">Get Free Estimate</Link>
          <a href={SITE.phoneHref} className="btn-outline-light mt-3 w-full"><Phone className="h-4 w-4" />{SITE.phone}</a>
          <div className="mt-10 border-t border-ivory/15 pt-6">
            <p className="eyebrow mb-4">Related</p>
            {others.map((o) => (
              <Link key={o.slug} to="/services/$slug" params={{ slug: o.slug }} className="block py-1.5 text-sm text-ivory/75 hover:text-gold">{o.title}</Link>
            ))}
          </div>
        </aside>
      </section>
    </>
  );
}
