import { createFileRoute } from "@tanstack/react-router";
import { Phone, Mail, MapPin } from "lucide-react";
import hero from "@/assets/hero-painting.jpg";
import { PageHero } from "@/components/site/Layout";
import { EstimateForm } from "@/components/site/EstimateForm";
import { SITE } from "@/lib/site";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Get a Free Estimate | Lucent General Contractors" },
      { name: "description", content: "Request a free painting or construction estimate in Grand Rapids, Lansing or Traverse City. Call 517-525-6241." },
      { property: "og:title", content: "Contact Lucent General Contractors" },
      { property: "og:description", content: "Request your free estimate today." },
    ],
  }),
  component: Contact,
});

function Contact() {
  return (
    <>
      <PageHero eyebrow="Contact" title="Request Your Free Estimate" sub="Tell us about your project and we'll respond within one business day." image={hero} />
      <section className="mx-auto grid max-w-7xl gap-16 px-5 py-24 lg:grid-cols-[1fr_1.5fr] lg:px-8">
        <div className="space-y-8">
          <a href={SITE.phoneHref} className="btn-gold w-full"><Phone className="h-4 w-4" /> Call {SITE.phone}</a>
          <div className="space-y-5 text-sm">
            <a href={`mailto:${SITE.email}`} className="flex items-center gap-3 break-all hover:text-gold"><Mail className="h-5 w-5 text-gold" />{SITE.email}</a>
            <p className="flex items-center gap-3"><MapPin className="h-5 w-5 text-gold" />Grand Rapids · Lansing · Traverse City</p>
          </div>
          <div className="border border-border p-8">
            <p className="eyebrow">Prefer to schedule?</p>
            <p className="mt-3 font-display text-2xl">Book a free consultation call with James.</p>
            <a href={SITE.phoneHref} className="btn-outline-dark mt-6">Schedule by Phone</a>
          </div>
        </div>
        <div className="bg-card p-8 md:p-12 shadow-sm">
          <h2 className="text-3xl">Estimate Request Form</h2>
          <span className="gold-rule mt-4 mb-8" />
          <EstimateForm />
        </div>
      </section>
      <section className="h-[24rem] w-full">
        <iframe title="Map of our Michigan service area" className="h-full w-full grayscale" loading="lazy" src="https://www.google.com/maps?q=Michigan&z=6&output=embed" />
      </section>
    </>
  );
}
