import { createFileRoute } from "@tanstack/react-router";
import p2 from "@/assets/photo2.png";
import { PageHero } from "@/components/site/Layout";
import { Gallery } from "@/components/site/Gallery";

export const Route = createFileRoute("/portfolio")({
  head: () => ({
    meta: [
      { title: "Project Portfolio | Lucent General Contractors" },
      { name: "description", content: "Commercial projects, accent walls, painting and renovation work by Lucent General Contractors in Grand Rapids, Lansing & Traverse City." },
      { property: "og:title", content: "Portfolio | Lucent General Contractors" },
      { property: "og:description", content: "See our painting, accent wall and renovation projects." },
    ],
  }),
  component: Portfolio,
});

function Portfolio() {
  return (
    <>
      <PageHero eyebrow="Portfolio" title="Work that speaks for itself." sub="Commercial projects, accent walls, painting and renovation — click any project to view it larger." image={p2.url} />
      <section className="mx-auto max-w-7xl px-5 py-24 lg:px-8">
        <Gallery filters />
      </section>
    </>
  );
}
