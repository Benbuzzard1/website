import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import ext from "@/assets/exterior-home.jpg";
import { PageHero } from "@/components/site/Layout";
import { SERVICES } from "@/lib/site";

export const Route = createFileRoute("/services/")({
  head: () => ({
    meta: [
      { title: "Painting & Construction Services | Lucent General Contractors" },
      { name: "description", content: "Interior, exterior, commercial and residential painting, drywall repair, remodeling, rental turnovers and property maintenance in Grand Rapids, Lansing & Traverse City." },
      { property: "og:title", content: "Services | Lucent General Contractors" },
      { property: "og:description", content: "Residential & commercial painting services and light construction in Grand Rapids, Lansing & Traverse City." },
    ],
  }),
  component: Services,
});

function Services() {
  return (
    <>
      <PageHero eyebrow="Services" title="Residential & Commercial Painting Services" sub="Painting is our specialty. Construction, remodeling and maintenance complete the picture." image={ext} />
      <section className="mx-auto max-w-7xl px-5 py-24 lg:px-8">
        <div className="grid gap-px bg-border md:grid-cols-2">
          {SERVICES.map((s, i) => (
            <Link key={s.slug} to="/services/$slug" params={{ slug: s.slug }} className="group bg-background p-10 hover:bg-ink transition-colors">
              <div className="flex items-baseline justify-between">
                <span className="font-display text-gold">{String(i + 1).padStart(2, "0")}</span>
                {s.primary && <span className="text-[0.62rem] uppercase tracking-[0.25em] text-gold">Specialty</span>}
              </div>
              <h2 className="mt-4 text-3xl group-hover:text-ivory">{s.title}</h2>
              <p className="mt-3 text-muted-foreground group-hover:text-ivory/60">{s.short}</p>
              <span className="mt-6 inline-flex items-center gap-2 text-xs uppercase tracking-[0.2em] text-gold">Learn more <ArrowRight className="h-4 w-4" /></span>
            </Link>
          ))}
        </div>
      </section>
    </>
  );
}
