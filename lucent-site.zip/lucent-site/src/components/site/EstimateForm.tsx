import { useState, type FormEvent } from "react";
import { SERVICES, SITE } from "@/lib/site";

export function EstimateForm({ dark = false }: { dark?: boolean }) {
  const [sent, setSent] = useState(false);
  const field = dark
    ? "w-full bg-transparent border-b border-ivory/25 py-3 text-ivory placeholder:text-ivory/40 focus:border-gold focus:outline-none transition-colors"
    : "w-full bg-transparent border-b border-input py-3 text-foreground placeholder:text-muted-foreground focus:border-gold focus:outline-none transition-colors";

  function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const d = new FormData(e.currentTarget);
    const body = [
      `Name: ${d.get("name")}`,
      `Phone: ${d.get("phone")}`,
      `Email: ${d.get("email")}`,
      `Property Address: ${d.get("address")}`,
      `Project Type: ${d.get("type")}`,
      "",
      `${d.get("description")}`,
    ].join("\n");
    window.location.href = `mailto:${SITE.email}?subject=${encodeURIComponent("Free Estimate Request")}&body=${encodeURIComponent(body)}`;
    setSent(true);
  }

  return (
    <form onSubmit={onSubmit} className="grid gap-5 sm:grid-cols-2">
      <input required name="name" placeholder="Full name" className={field} />
      <input required name="phone" type="tel" placeholder="Phone" className={field} />
      <input required name="email" type="email" placeholder="Email" className={field} />
      <input name="address" placeholder="Property address" className={field} />
      <select required name="type" defaultValue="" className={`${field} sm:col-span-2 ${dark ? "[&>option]:text-ink" : ""}`}>
        <option value="" disabled>Project type</option>
        {SERVICES.map((s) => <option key={s.slug}>{s.title}</option>)}
        <option>Other</option>
      </select>
      <textarea required name="description" rows={3} placeholder="Tell us about your project" className={`${field} sm:col-span-2 resize-none`} />
      <label className={`sm:col-span-2 text-xs tracking-wide ${dark ? "text-ivory/60" : "text-muted-foreground"}`}>
        Project photos (optional — attach them to the email that opens)
        <input name="photos" type="file" accept="image/*" multiple className="mt-2 block w-full text-xs file:mr-4 file:border-0 file:bg-gold file:px-4 file:py-2 file:text-ink" />
      </label>
      <div className="sm:col-span-2 flex flex-wrap items-center gap-4 pt-2">
        <button type="submit" className="btn-gold">Get My Free Estimate</button>
        {sent && <span className={`text-sm ${dark ? "text-ivory/70" : "text-muted-foreground"}`}>Your email app should open — just hit send.</span>}
      </div>
    </form>
  );
}
