import { useState } from "react";
import { X } from "lucide-react";
import p1 from "@/assets/photo1.png";
import p2 from "@/assets/photo2.png";
import p3 from "@/assets/photo3.png";
import ext from "@/assets/exterior-home.jpg";
import hero from "@/assets/hero-painting.jpg";
import craft from "@/assets/craft-detail.jpg";

export const PROJECTS = [
  { src: p2.url, title: "Golf Mural Accent Wall", cat: "Accent Walls" },
  { src: p3.url, title: "Reclaimed Wood Reception Counter", cat: "Renovation" },
  { src: p1.url, title: "24/7 Golf Storefront", cat: "Commercial" },
  { src: hero, title: "Living Room Repaint", cat: "Painting" },
  { src: ext, title: "Craftsman Exterior", cat: "Painting" },
  { src: craft, title: "Interior Finish Work", cat: "Painting" },
];
const CATS = ["All", "Commercial", "Accent Walls", "Painting", "Renovation"];

export function Gallery({ filters = false }: { filters?: boolean }) {
  const [cat, setCat] = useState("All");
  const [open, setOpen] = useState<number | null>(null);
  const items = PROJECTS.filter((p) => cat === "All" || p.cat === cat);
  return (
    <>
      {filters && (
        <div className="mb-10 flex flex-wrap gap-2">
          {CATS.map((c) => (
            <button key={c} onClick={() => setCat(c)} className={`px-5 py-2 text-xs uppercase tracking-[0.2em] border transition-colors ${cat === c ? "bg-ink text-ivory border-ink" : "border-border hover:border-gold"}`}>{c}</button>
          ))}
        </div>
      )}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {items.map((p, i) => (
          <button key={p.title} onClick={() => setOpen(PROJECTS.indexOf(p))} className={`group relative overflow-hidden bg-ink text-left ${i === 0 ? "lg:row-span-2" : ""}`}>
            <img src={p.src} alt={p.title} loading="lazy" className={`h-full w-full object-cover transition-transform duration-700 group-hover:scale-105 ${i === 0 ? "min-h-[24rem]" : "aspect-[4/3]"}`} />
            <div className="absolute inset-0 bg-gradient-to-t from-ink/90 via-ink/10 to-transparent" />
            <div className="absolute bottom-0 p-6">
              <p className="eyebrow">{p.cat}</p>
              <p className="mt-1 font-display text-2xl text-ivory">{p.title}</p>
            </div>
          </button>
        ))}
      </div>
      {open !== null && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-ink/95 p-6" onClick={() => setOpen(null)}>
          <button aria-label="Close" className="absolute right-6 top-6 text-ivory"><X className="h-8 w-8" /></button>
          <figure className="max-w-5xl">
            <img src={PROJECTS[open]?.src} alt={PROJECTS[open]?.title} className="max-h-[80vh] w-auto mx-auto" />
            <figcaption className="mt-4 text-center font-display text-2xl text-ivory">{PROJECTS[open]?.title}</figcaption>
          </figure>
        </div>
      )}
    </>
  );
}
