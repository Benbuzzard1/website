import { Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Menu, Phone, X, Mail, ShieldCheck, Award, BadgeCheck } from "lucide-react";
import logo from "@/assets/business_logo.png";
import { NAV, SERVICES, SITE, AREAS } from "@/lib/site";
import { EstimateForm } from "./EstimateForm";

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const f = () => setScrolled(window.scrollY > 20);
    f();
    window.addEventListener("scroll", f);
    return () => window.removeEventListener("scroll", f);
  }, []);
  return (
    <header className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ${scrolled || open ? "bg-ink/95 backdrop-blur py-3 shadow-lg" : "bg-transparent py-5"}`}>
      <div className="mx-auto flex max-w-7xl items-center justify-between px-5 lg:px-8">
        <Link to="/" className="flex items-center gap-3" onClick={() => setOpen(false)}>
          <img src={logo.url} alt="Lucent General Contractors logo" className="h-12 w-12 rounded-full" />
          <span className="hidden sm:block leading-tight">
            <span className="block font-display text-xl tracking-[0.25em] text-ivory">LUCENT</span>
            <span className="block text-[0.6rem] tracking-[0.3em] text-gold">GENERAL CONTRACTORS</span>
          </span>
        </Link>
        <nav className="hidden lg:flex items-center gap-8">
          {NAV.map((n) => (
            <Link key={n.to} to={n.to} activeOptions={{ exact: n.to === "/" }} className="text-[0.72rem] uppercase tracking-[0.22em] text-ivory/80 hover:text-gold transition-colors" activeProps={{ className: "!text-gold" }}>
              {n.label}
            </Link>
          ))}
        </nav>
        <div className="flex items-center gap-3">
          <a href={SITE.phoneHref} className="hidden md:inline-flex items-center gap-2 text-sm text-ivory hover:text-gold">
            <Phone className="h-4 w-4 text-gold" /> {SITE.phone}
          </a>
          <Link to="/contact" className="btn-gold hidden sm:inline-flex !py-3 !px-5">Free Estimate</Link>
          <button aria-label="Menu" onClick={() => setOpen(!open)} className="lg:hidden text-ivory p-2">
            {open ? <X /> : <Menu />}
          </button>
        </div>
      </div>
      {open && (
        <nav className="lg:hidden mx-auto max-w-7xl px-5 pb-6 pt-4 flex flex-col gap-4">
          {NAV.map((n) => (
            <Link key={n.to} to={n.to} onClick={() => setOpen(false)} className="font-display text-2xl text-ivory hover:text-gold">{n.label}</Link>
          ))}
        </nav>
      )}
    </header>
  );
}

export function EstimateBand() {
  return (
    <section className="bg-ink text-ivory">
      <div className="mx-auto grid max-w-7xl gap-14 px-5 py-24 lg:grid-cols-[1fr_1.3fr] lg:px-8">
        <div>
          <p className="eyebrow">Free Estimate</p>
          <h2 className="mt-4 text-4xl md:text-5xl leading-tight">Ready To Transform Your Property?</h2>
          <p className="mt-5 text-ivory/70 max-w-md">Let's discuss your next painting or construction project. We respond within one business day.</p>
          <div className="mt-8 space-y-3 text-sm">
            <a href={SITE.phoneHref} className="flex items-center gap-3 hover:text-gold"><Phone className="h-4 w-4 text-gold" />{SITE.phone}</a>
            <a href={`mailto:${SITE.email}`} className="flex items-center gap-3 hover:text-gold break-all"><Mail className="h-4 w-4 text-gold" />{SITE.email}</a>
          </div>
          <TrustBadges dark />
        </div>
        <EstimateForm dark />
      </div>
    </section>
  );
}

export function TrustBadges({ dark = false }: { dark?: boolean }) {
  const items = [
    { icon: ShieldCheck, label: "Licensed & Insured" },
    { icon: Award, label: "Quality Guaranteed" },
    { icon: BadgeCheck, label: "Locally Owned" },
  ];
  return (
    <div className="mt-10 flex flex-wrap gap-6">
      {items.map(({ icon: I, label }) => (
        <div key={label} className={`flex items-center gap-2 text-[0.68rem] uppercase tracking-[0.2em] ${dark ? "text-ivory/80" : "text-foreground/80"}`}>
          <I className="h-5 w-5 text-gold" /> {label}
        </div>
      ))}
    </div>
  );
}

export function SiteFooter() {
  return (
    <footer className="bg-ink text-ivory/70 border-t border-ivory/10">
      <div className="mx-auto grid max-w-7xl gap-12 px-5 py-16 md:grid-cols-4 lg:px-8">
        <div>
          <img src={logo.url} alt="Lucent" className="h-20 w-20 rounded-full" />
          <p className="mt-5 font-display text-xl italic text-ivory">{SITE.tagline}</p>
        </div>
        <div>
          <p className="eyebrow mb-4">Painting</p>
          <ul className="space-y-2 text-sm">
            {SERVICES.slice(0, 5).map((s) => <li key={s.slug}><Link to="/services/$slug" params={{ slug: s.slug }} className="hover:text-gold">{s.title}</Link></li>)}
          </ul>
        </div>
        <div>
          <p className="eyebrow mb-4">Construction</p>
          <ul className="space-y-2 text-sm">
            {SERVICES.slice(5).map((s) => <li key={s.slug}><Link to="/services/$slug" params={{ slug: s.slug }} className="hover:text-gold">{s.title}</Link></li>)}
          </ul>
        </div>
        <div>
          <p className="eyebrow mb-4">Contact</p>
          <ul className="space-y-2 text-sm">
            <li><a href={SITE.phoneHref} className="hover:text-gold">{SITE.phone}</a></li>
            <li><a href={`mailto:${SITE.email}`} className="hover:text-gold break-all">{SITE.email}</a></li>
            <li className="pt-2">Serving {AREAS.map((a) => a.city).join(" · ")}</li>
          </ul>
        </div>
      </div>
      <div className="border-t border-ivory/10 py-6 text-center text-xs tracking-wider">
        © {new Date().getFullYear()} {SITE.name}. All rights reserved.
      </div>
    </footer>
  );
}

export function MobileCallBar() {
  return (
    <div className="fixed inset-x-0 bottom-0 z-40 grid grid-cols-2 md:hidden">
      <a href={SITE.phoneHref} className="flex items-center justify-center gap-2 bg-ink py-4 text-xs uppercase tracking-[0.2em] text-ivory border-t border-gold/40">
        <Phone className="h-4 w-4 text-gold" /> Call Now
      </a>
      <Link to="/contact" className="flex items-center justify-center bg-gold py-4 text-xs uppercase tracking-[0.2em] text-ink">Free Estimate</Link>
    </div>
  );
}

export function StickyEstimate() {
  return (
    <Link to="/contact" className="btn-gold shadow-gold fixed bottom-6 right-6 z-40 hidden md:inline-flex">Get Free Estimate</Link>
  );
}

export function PageHero({ eyebrow, title, sub, image }: { eyebrow: string; title: string; sub?: string; image: string }) {
  return (
    <section className="relative flex min-h-[60vh] items-end overflow-hidden bg-ink">
      <img src={image} alt="" className="absolute inset-0 h-full w-full object-cover opacity-60" />
      <div className="absolute inset-0 bg-hero-overlay" />
      <div className="relative mx-auto w-full max-w-7xl px-5 pb-16 pt-40 lg:px-8 animate-rise">
        <p className="eyebrow">{eyebrow}</p>
        <h1 className="mt-4 max-w-3xl text-5xl md:text-6xl leading-[1.05] text-ivory">{title}</h1>
        {sub && <p className="mt-5 max-w-2xl text-ivory/75">{sub}</p>}
      </div>
    </section>
  );
}
