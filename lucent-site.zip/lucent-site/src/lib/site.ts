export const SITE = {
  name: "Lucent General Contractors LLC",
  short: "Lucent",
  phone: "517-525-6241",
  phoneHref: "tel:+15175256241",
  email: "JamesF@LucentContractors.com",
  tagline: "Building Trust. Delivering Quality.",
  owner: "James Felton",
};

export type Service = {
  slug: string;
  title: string;
  short: string;
  intro: string;
  points: string[];
  keyword: string;
  primary?: boolean;
};

export const SERVICES: Service[] = [
  {
    slug: "interior-painting",
    title: "Interior Painting",
    primary: true,
    short: "Flawless walls, ceilings, trim and cabinetry with crisp lines and lasting finishes.",
    intro:
      "Our interior painting service brings clean, precise, long-lasting finishes to homes and businesses across Grand Rapids, Lansing and Traverse City. Every project begins with careful surface preparation, protection of your floors and furnishings, and premium coatings selected for your space.",
    points: ["Walls, ceilings, trim & doors", "Cabinet refinishing", "Accent & feature walls", "Low-VOC premium paints", "Full furniture & floor protection", "Daily clean-up"],
    keyword: "Interior Painting Michigan",
  },
  {
    slug: "exterior-painting",
    title: "Exterior Painting",
    primary: true,
    short: "Weather-ready exterior coatings that protect and elevate your curb appeal.",
    intro:
      "Michigan seasons are hard on siding, trim and decks. Our exterior painting crews power-wash, scrape, repair, prime and finish with coatings engineered for Michigan weather — so your property looks sharp and stays protected for years.",
    points: ["Siding, trim & soffits", "Decks, fences & porches", "Power washing & prep", "Caulking & wood repair", "Color consultation", "Commercial exteriors"],
    keyword: "Exterior Painting Michigan",
  },
  {
    slug: "commercial-painting",
    title: "Commercial Painting",
    primary: true,
    short: "Offices, retail, restaurants and multi-family — scheduled around your business.",
    intro:
      "From offices and retail spaces to restaurants and multi-family buildings, Lucent delivers commercial painting with minimal disruption. We work evenings and weekends when needed, coordinate with property managers and builders, and keep projects on schedule.",
    points: ["Offices & retail spaces", "Restaurants & hospitality", "Multi-family housing", "After-hours scheduling", "Builder & GC partnerships", "Signage & feature walls"],
    keyword: "Commercial Painter Michigan",
  },
  {
    slug: "residential-painting",
    title: "Residential Painting",
    primary: true,
    short: "Respectful, detail-driven painting for the home you love.",
    intro:
      "We treat every home like our own. Our residential painting service combines honest communication, tidy job sites and meticulous craftsmanship — whether it's a single room refresh or a whole-home transformation.",
    points: ["Whole-home repaints", "Single room refreshes", "Nurseries & bedrooms", "Kitchens & bathrooms", "Trim & millwork", "Clear, written estimates"],
    keyword: "Residential Painting Services",
  },
  {
    slug: "drywall-repair",
    title: "Drywall Repair",
    short: "Seamless patches, texture matching and finishing — ready for paint.",
    intro:
      "Holes, cracks, water damage and dings disappear with our professional drywall repair. We patch, tape, mud, sand and match texture so the repair is invisible once painted.",
    points: ["Hole & crack repair", "Water damage repair", "Texture matching", "Tape & mud finishing", "New drywall installs", "Paint-ready results"],
    keyword: "Drywall Repair Michigan",
  },
  {
    slug: "remodeling",
    title: "Remodeling",
    short: "Thoughtful updates that modernize kitchens, baths and living spaces.",
    intro:
      "Lucent handles light remodeling projects that refresh and modernize your property — from kitchen and bath updates to trim, flooring and fixture upgrades — all with the same finish quality we bring to painting.",
    points: ["Kitchen & bath updates", "Trim & millwork", "Fixture upgrades", "Flooring transitions", "Wall paneling & wood features", "Project coordination"],
    keyword: "General Contractor Michigan",
  },
  {
    slug: "property-maintenance",
    title: "Property Maintenance",
    short: "Dependable ongoing upkeep for owners and property managers.",
    intro:
      "Keep your properties in top condition with reliable maintenance from a single trusted contractor. We support homeowners, landlords and property managers with scheduled and on-call services.",
    points: ["Touch-up painting", "Minor repairs", "Caulking & sealing", "Seasonal maintenance", "Property manager support", "Fast response times"],
    keyword: "Property Maintenance Services",
  },
  {
    slug: "rental-turnovers",
    title: "Rental Turnovers",
    short: "Fast, clean make-readies that get units leased sooner.",
    intro:
      "Vacant units cost money. Our rental turnover service gets apartments and rental homes rent-ready quickly with paint, patching, repairs and punch-list work — on a timeline that respects your bottom line.",
    points: ["Full unit repaints", "Patch & repair", "Punch-list completion", "Fast turnaround", "Multi-unit pricing", "Photo updates on completion"],
    keyword: "Rental Turnover Painting",
  },
  {
    slug: "light-construction",
    title: "Light Construction",
    short: "Framing, carpentry and build-outs handled with care.",
    intro:
      "Our light construction services cover small build-outs, carpentry, framing and custom features — including the wood accent walls and reception counters we've built for commercial clients.",
    points: ["Framing & carpentry", "Accent wood walls", "Reception & bar counters", "Small build-outs", "Trim installation", "Commercial fit-outs"],
    keyword: "General Contractor Michigan",
  },
  {
    slug: "investor-property-improvements",
    title: "Investor Property Improvements",
    short: "Value-adding upgrades for investors and house flippers.",
    intro:
      "We partner with real estate investors and house flippers to maximize return — prioritizing the improvements buyers and tenants notice most, delivered on budget and on schedule.",
    points: ["Flip & resale prep", "Paint & cosmetic upgrades", "Repair scopes", "Budget-focused planning", "Reliable timelines", "Repeat-investor partnerships"],
    keyword: "Investor Property Improvements Michigan",
  },
];

export const AREAS = [
  { slug: "grand-rapids", city: "Grand Rapids", h: "Painting Contractor Grand Rapids MI", body: "Lucent is a trusted painter in Grand Rapids, MI, serving homeowners, businesses and property managers across Kent County — including East Grand Rapids, Wyoming, Kentwood, Walker and Ada — with interior, exterior and commercial painting." },
  { slug: "lansing", city: "Lansing", h: "Painting Contractor Lansing MI", body: "As a Lansing painting contractor, we serve Lansing, East Lansing, Okemos, Holt and DeWitt with residential repaints, rental turnovers and commercial painting delivered on schedule." },
  { slug: "traverse-city", city: "Traverse City", h: "Painting Contractor Traverse City MI", body: "Looking for a Traverse City painter? We bring premium interior and exterior painting to Traverse City, Grand Traverse County and the surrounding lakeshore communities." },
];

export const NAV = [
  { to: "/", label: "Home" },
  { to: "/services", label: "Services" },
  { to: "/portfolio", label: "Portfolio" },
  { to: "/about", label: "About" },
  { to: "/service-areas", label: "Service Areas" },
  { to: "/contact", label: "Contact" },
] as const;

export const FAQS = [
  { q: "Do you offer free estimates?", a: "Yes. Every estimate is free, detailed and in writing, with no obligation." },
  { q: "Are you licensed and insured?", a: "Yes. Lucent General Contractors LLC is fully insured, and we're happy to provide documentation before work begins." },
  { q: "What areas do you serve?", a: "Grand Rapids, Lansing and Traverse City, plus the communities around them." },
  { q: "Do you work weekends or after hours?", a: "Yes. We offer weekend and after-hours scheduling, especially for commercial clients who can't close during the day." },
  { q: "Do you work with property managers and investors?", a: "Absolutely. Rental turnovers, ongoing maintenance and investor improvements are a core part of our business." },
  { q: "How soon can you start?", a: "We respond quickly — usually within one business day — and schedule work around your timeline." },
];
